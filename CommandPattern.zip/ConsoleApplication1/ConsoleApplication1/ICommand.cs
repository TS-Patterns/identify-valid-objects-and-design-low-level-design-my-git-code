﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oven
{
    internal interface ICommand
    {
        void Execute();
    }
}
