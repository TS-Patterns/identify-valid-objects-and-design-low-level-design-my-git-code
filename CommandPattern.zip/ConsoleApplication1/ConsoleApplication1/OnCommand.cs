﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oven
{
    internal class OnCommand : ICommand
    {
        private Oven _oven;

        internal OnCommand(Oven oven)
        {
            _oven = oven;
        }

        public void Execute()
        {
            _oven.PowerButtonOn();
        }
    }
}
