﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oven
{
    internal class Add30MinsCommand : ICommand
    {
        private Oven _oven;

        internal Add30MinsCommand(Oven oven)
        {
            _oven = oven;
        }

        public void Execute()
        {
            _oven.Add30MinsToClock();
        }
    }
}
