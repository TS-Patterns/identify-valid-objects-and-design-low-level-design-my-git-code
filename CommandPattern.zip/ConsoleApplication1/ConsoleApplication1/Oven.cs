﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oven
{
    class Oven
    {
        internal void PowerButtonOn()
        {
            Console.WriteLine("Oven is On");
        }

        internal void PowerButtonOff()
        {
            Console.WriteLine("Oven is Off");
        }

        internal void ResetOvenTimer()
        {
            Console.WriteLine("Reset the timer ");
        }

        internal void Add30MinsToClock()
        {
            Console.WriteLine("Add 30 mins to the Timer");
        }
    }
}
