﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oven
{
    class Invoker
    {
        static void Main(string[] args)
        {
            IDictionary<int, ICommand> commandOptions = new Dictionary<int, ICommand>();
            var oven = new Oven();
            commandOptions.Add(1, new OnCommand(oven));
            commandOptions.Add(2, new OffCommand(oven));
            commandOptions.Add(3, new ResetCommand(oven));
            commandOptions.Add(4, new Add30MinsCommand(oven));
            Console.WriteLine("Menu: 1:On 2:Off 3:Add 30 mins 4:Clear");
            int userInput;
            var isParsed = int.TryParse(Console.ReadLine(), out userInput);
            if (isParsed && commandOptions.ContainsKey(userInput))
            { 
                commandOptions[userInput].Execute(); 
            }
            Console.ReadLine();
        }
    }
}
