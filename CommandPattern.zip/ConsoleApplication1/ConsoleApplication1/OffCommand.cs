﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oven
{
    internal class OffCommand : ICommand
    {
        private Oven _oven;

        internal OffCommand(Oven oven)
        {
            _oven = oven;
        }

        public void Execute()
        {
            _oven.PowerButtonOff();
        }
    }
}
