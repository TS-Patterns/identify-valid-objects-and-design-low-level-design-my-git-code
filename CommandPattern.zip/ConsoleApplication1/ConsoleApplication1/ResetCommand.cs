﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Oven
{
    internal class ResetCommand : ICommand
    {
        private Oven _oven;

        internal ResetCommand(Oven oven)
        {
            _oven = oven;
        }

        public void Execute()
        {
            _oven.ResetOvenTimer();
        }        
    }
}
