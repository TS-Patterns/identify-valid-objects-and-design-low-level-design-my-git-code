﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignProblem
{
    class Program
    {
        static void Main(string[] args)
        {
            Document obj = new Document();
            obj.Add(new Paragraph());
            obj.Add(new Hyperlink());                            
        }
    }
}
