﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignProblem
{
    class PdfConverter : IDocumentConverter
    {
        public void ConvertParagraph(Paragraph paragraph)
        {
            Console.WriteLine("Convert paragraph to XPS");
        }

        public void ConvertHyperlink(Hyperlink hyperlink)
        {
            Console.WriteLine("Convert hyperlink to XPS");
        }
    }
}
