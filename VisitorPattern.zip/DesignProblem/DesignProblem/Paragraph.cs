﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignProblem
{
    class Paragraph : IDocumentPart
    {
        public void Convert(IDocumentConverter documentConverter)
        {
            documentConverter.ConvertParagraph(this);
        }
    }
}
