﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DesignProblem
{
    class Document
    {
        private List<IDocumentPart> documentParts;

        public void Add(IDocumentPart documentPart)
        {
            documentParts.Add(documentPart);
        }

        public void Convert(IDocumentConverter documentConverter)
        {
            foreach (var documentPart in documentParts)
            {
                documentPart.Convert(documentConverter);                                        
            }
        }
    }
}
